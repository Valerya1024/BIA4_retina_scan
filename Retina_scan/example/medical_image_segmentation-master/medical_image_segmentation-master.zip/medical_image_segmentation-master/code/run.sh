python baseline_aug.py > logs_baseline.txt
python baseline_aug_vgg.py > logs_vgg.txt
python baseline.py > logs.txt
python baseline_aug_predict.py > logs_baseline_predict.txt
python baseline_aug_vgg_predict.py > logs_vgg_predict.txt
python baseline_predict.py > logs_predict.txt